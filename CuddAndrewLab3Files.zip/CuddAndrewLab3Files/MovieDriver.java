import java.util.Scanner;
public class MovieDriver {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Movie obj = new Movie();
		char answer;
		do {
		System.out.println("Enter the title of a movie");
		String title = input.nextLine();
		obj.setTitle(title);
		System.out.println("Enter the movies rating");
		String rating = input.nextLine();
		obj.setRating(rating);
		System.out.println("Enter the number of tickets sold for this move");
		int soldTickets = input.nextInt();
		obj.setSoldTickets(soldTickets);
		System.out.println(obj.toString());
		System.out.println("Do you want to enter another? (y or n)");
		input.nextLine();
		answer = input.nextLine().charAt(0);
		}
		while(answer == 'y');
		input.close();
	}

}
